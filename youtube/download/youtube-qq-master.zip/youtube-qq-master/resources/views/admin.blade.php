<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>腾讯视频-管理员后台</title>
</head>
<body>
	You have logged in as ADMIN!
</body>
</html>