<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>电子邮件</title>
</head>
<body>
	<h1>蔡镇慈</h1>
	<p>欢迎，这是您收到的第一封电子邮件</p>
</body>
</html>