<div class="custom-jumbotron text-white">
    <h1 class="display-4">精彩评论</h1>
    <p>下面是其他小伙伴的精彩评论，看看别人怎么说的吧</p><br/>
</div>