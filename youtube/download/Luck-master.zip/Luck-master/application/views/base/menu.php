<nav id="menu">
    <ul>
        <li><a href="<?php echo site_url('home/index');?>">抽奖</a></li>
        <li><a href="<?php echo site_url('home/user');?>">参与人员</a></li>
        <li><a href="<?php echo site_url('home/grade');?>">奖项</a></li>
        <li><a href="<?php echo site_url('sign/joinus');?>">参与</a></li>
        <li><a href="<?php echo site_url('sign/signout');?>">退出</a></li>
    </ul>
</nav>