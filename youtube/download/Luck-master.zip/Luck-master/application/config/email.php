<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['protocol'] = 'smtp';
$config['smtp_host'] = 'smtp.163.com';
$config['smtp_user'] = 'vblue7@163.com';
$config['smtp_pass'] = 'kqmhaotaeytjnjrof';